package com.uniappliances.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val PHONE = "9123631967"
private const val WHATSAPP = "919123631967"

data class Service(val icon: String, val name: String, val description: String)

private val services = listOf(
    Service("❄️", "AC Service", "Repair, installation & maintenance"),
    Service("🧊", "Refrigerator", "Cooling, gas & electrical repairs"),
    Service("🧺", "Washing Machine", "All brands & common faults"),
    Service("🍽️", "Microwave", "Heating & electrical repairs")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UniApp() }
    }

    private fun call() {
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$PHONE")))
    }

    private fun whatsapp(message: String = "Hello UNI APPLIANCES, I want to book a home appliance repair service.") {
        val url = "https://wa.me/$WHATSAPP?text=" + Uri.encode(message)
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    @Composable
    fun UniApp() {
        var showBooking by remember { mutableStateOf(false) }
        var selected by remember { mutableStateOf<Service?>(null) }

        MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF0B3D91))) {
            if (showBooking) {
                BookingScreen(
                    service = selected,
                    onBack = { showBooking = false },
                    onWhatsApp = { whatsapp(it) }
                )
            } else {
                HomeScreen(
                    onBook = { selected = it; showBooking = true },
                    onCall = { call() },
                    onWhatsApp = { whatsapp() }
                )
            }
        }
    }

    @Composable
    fun HomeScreen(onBook: (Service?) -> Unit, onCall: () -> Unit, onWhatsApp: () -> Unit) {
        Column(
            modifier = Modifier.fillMaxSize().background(Color(0xFFF5F8FC)).padding(18.dp)
        ) {
            Text("UNI APPLIANCES", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF0B3D91))
            Text("HOME APPLIANCE REPAIR SERVICE", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("Kolkata • All major brands", color = Color.Gray)

            Spacer(Modifier.height(18.dp))

            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0B3D91)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text("Need a technician?", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Book AC, refrigerator, washing machine or microwave service.", color = Color.White)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = { onBook(null) }, modifier = Modifier.fillMaxWidth()) {
                        Text("BOOK A SERVICE")
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("OUR SERVICES", fontSize = 18.sp, fontWeight = FontWeight.Bold)

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(services) { service ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onBook(service) },
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(service.icon, fontSize = 32.sp)
                            Text(service.name, fontWeight = FontWeight.Bold)
                            Text(service.description, fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onCall, modifier = Modifier.weight(1f)) { Text("📞 CALL") }
                Button(onClick = onWhatsApp, modifier = Modifier.weight(1f)) { Text("💬 WHATSAPP") }
            }
        }
    }

    @Composable
    fun BookingScreen(service: Service?, onBack: () -> Unit, onWhatsApp: (String) -> Unit) {
        var name by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var appliance by remember { mutableStateOf(service?.name ?: "") }
        var brand by remember { mutableStateOf("") }
        var problem by remember { mutableStateOf("") }
        var address by remember { mutableStateOf("") }
        var date by remember { mutableStateOf("") }
        var time by remember { mutableStateOf("") }
        var submitted by remember { mutableStateOf(false) }

        if (submitted) {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("✅", fontSize = 54.sp)
                Text("Booking Request Ready", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Send the booking details to UNI APPLIANCES on WhatsApp to confirm the service.")
                Spacer(Modifier.height(20.dp))
                Button(onClick = {
                    val msg = """UNI APPLIANCES SERVICE BOOKING
Name: $name
Mobile: $phone
Appliance: $appliance
Brand: $brand
Problem: $problem
Address: $address
Preferred Date: $date
Preferred Time: $time"""
                    onWhatsApp(msg)
                }) { Text("SEND ON WHATSAPP") }
                TextButton(onClick = onBack) { Text("Back to Home") }
            }
            return
        }

        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← Back") }
                Text("BOOK A SERVICE", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            androidx.compose.foundation.lazy.LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                item { Field("Customer Name", name) { name = it } }
                item { Field("Mobile Number", phone) { phone = it } }
                item { Field("Appliance", appliance) { appliance = it } }
                item { Field("Brand", brand) { brand = it } }
                item { Field("Problem / Service Required", problem) { problem = it } }
                item { Field("Full Address", address) { address = it } }
                item { Field("Preferred Date", date) { date = it } }
                item { Field("Preferred Time", time) { time = it } }
                item {
                    Button(
                        onClick = { submitted = true },
                        enabled = name.isNotBlank() && phone.isNotBlank() && appliance.isNotBlank() && address.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("SUBMIT BOOKING") }
                }
            }
        }
    }

    @Composable
    fun Field(label: String, value: String, onValue: (String) -> Unit) {
        OutlinedTextField(
            value = value,
            onValueChange = onValue,
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = label != "Problem / Service Required" && label != "Full Address"
        )
    }
}
