# UNI APPLIANCES Android App — Version 1.0

A first Android Studio version for UNI APPLIANCES home appliance repair service.

Included:
- AC, refrigerator, washing machine and microwave services
- Online booking form
- Phone call booking
- WhatsApp booking
- Booking confirmation screen
- Kolkata service branding

Business phone configured: 9123631967

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone or start an emulator.
4. Press Run.

For a production release, connect the booking form to a backend/database and add an admin dashboard, engineer assignment, authentication, invoices and payment gateway.
